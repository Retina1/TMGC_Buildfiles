# [\[FE8 Ephraim-Variant\] \[M\] T1 Vanilla Repack +Weapons](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FLords%20-%20Vanilla%20and%20Custom%2F%5BFE8%20Ephraim-Variant%5D%20%5BM%5D%20T1%20Vanilla%20Repack%20%2BWeapons%2F5.%20Bow)

## Bow

| Still | Animation |
| :---: | :-------: |
| ![Bow still](./Bow_000.png) | ![Bow](./Bow.gif) |

## Credit

Vanilla animation by IS.

Additional weapons (???) by DerTheVaporeon, Pikmin1211.

Staff by ZoramineFae.

Fixed Staff by Permafrost. This fix allows the staff to ALSO be used as a magic animation, if desired.
